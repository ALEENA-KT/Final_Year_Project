1. For getting started with ccs studio, extract the file project_28379d.zip.
2. You must have install control suite or c2000 into the ti directory created while installing ccs for debugging the project.
3. Once finished installing CCS and C2000, Open the CCS studio application.
4. Go to Project/import CCS project.
5. Browse for the project hello_28379.
6. Press finish and the project will be available on workspace.
7. Read the comment portions in the sample code corresponding to the module of interest and configure the registers accordingly (TMS320F2837xD.pdf and tms320f28377d_datasheet.pdf)
8. If needed, add more source files from the control suite or c200ware source folders by right clinking the project folder in ccs.
9. Read the document LAUNCHXL-F28379D_SCH.pdf for getting more information about the input and output pin assignment.
10. I have considered many errors in v1.1 for developing the general source code but read the document LAUNCHXL-F28379D_overview.pdf for getting more information about the different versions of launch pad and error correction details.