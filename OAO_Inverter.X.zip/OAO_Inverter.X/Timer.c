#include "Timer.h"

void Timer_1_Init(void){
    T1CONbits.TSIDL = 0;
    T1CONbits.TGATE = 0;
    T1CONbits.TCKPS = 0b01; //Prescale to 1:8
    T1CONbits.TCS = 0;
    TMR1 = 0x00;
    PR1 = PR1_MAX;
    IFS0bits.T1IF = 0;
    IEC0bits.T1IE = 0;
//    IPC0bits.T1IP = 0b000;
    T1CONbits.TON = 0;
}

void Timer_1_Run(void){
    TMR1 = 0x00;
    IFS0bits.T1IF = 0;
    IEC0bits.T1IE = 1;
    T1CONbits.TON = 1;
}

void Timer_1_Stop(void){
    TMR1 = 0x00;
    IFS0bits.T1IF = 0;
    IEC0bits.T1IE = 0;
    T1CONbits.TON = 0;
}