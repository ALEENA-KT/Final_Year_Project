
//Settings file for altering inverter specifications

//Password for entering to settings menu in inverter
#define _PASS_WORD 1232

//Low battery cutoff point in mV
//#define _LOW_BAT_TRAP 10500

//Low battery warning point in mV
//#define _LOW_BAT_WARNING 10900

//Battery charging restart point
#define _BATTERY_CHARGING_RESTART 12700

//AC Mains low cut point
#define _UPS_MODE_AC_LOW_CUT 170

//AC Mains low reconnect point
#define _UPS_MODE_AC_LOW_RECONNECT 185

//AC Mains high cut point
#define _UPS_MODE_AC_HIGH_CUT 260

//AC Mains high reconnect point
#define _UPS_MODE_AC_HIGH_RECONNECT 250

//AC Mains low cut point for inverter
#define _INV_MODE_AC_LOW_CUT 140

//AC Output voltage set point
#define _AC_OUTPUT_SET_POINT 215

//EEPROM Key for match
#define _EEPROM_KEY 50

//Output surge value
#define _OUTPUT_SURGE_MAXIMUM_VALUE 200

#define _TRIAL 35

#define _SLR_BAT_HIGH 14200
#define _SLR_BAT_LOW 11500
//Calibration menu item list
//Vbat calibration
//AcOut
//AcIn
//OutputVA
//Maximum output VA
//Maximum surge output VA
//Maximum load regulation factor
//Display type (LED = 0, LCD = 1) 

//Calculations overview
//Temperature calculation

//Optional address for EEPROM
#define _STAT_ADDRESS       0
#define _VBAT_ADDRESS       1
#define _ACOUT_ADDRESS      2
#define _ACIN_ADDRESS       3
#define _ACCURRENT_ADDRESS  4
#define _OUTMAX_ADDRESS     5
#define _SURGE_ADDRESS      6
#define _REGULATION_ADDRESS 7
#define _DISPLAY_ADDRESS    8
#define _BAT_LOW_ADDRESS    9
#define _RESTART_ADDRESS    10
#define _BAT_HIGH_ADDRESS   11
#define _CHARGING_ADDRESS   12
#define _BAT_AMPS_ADDRESS   13
#define _TRIAL_ADDRESS      14
