/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> // include processor files - each processor file is guarded.  

// TODO Insert appropriate #include <>

// TODO Insert C++ class definitions if appropriate

// TODO Insert declarations

// Comment a function and leverage automatic documentation with slash star star
/**
    <p><b>Function prototype:</b></p>
  
    <p><b>Summary:</b></p>

    <p><b>Description:</b></p>

    <p><b>Precondition:</b></p>

    <p><b>Parameters:</b></p>

    <p><b>Returns:</b></p>

    <p><b>Example:</b></p>
    <code>
 
    </code>

    <p><b>Remarks:</b></p>
 */
// TODO Insert declarations or function prototypes (right here) to leverage 
// live documentation

#ifdef	__cplusplus
extern "C" {
#endif /* __cplusplus */

    // TODO If C++ is being used, regular C code needs function names to have C 
    // linkage so the functions can be used by the c code. 

#ifdef	__cplusplus
}
#endif /* __cplusplus */

#endif	/* XC_HEADER_TEMPLATE_H */

#include <p30F2010.h>
#include <xc.h>

#define FCY     16000000
#include <libpic30.h>

#include "i2c.h"
#include "i2c_display.h"
#include "adc.h"
#include "ftoint.h"
//#include "table.h"
#include "pwm.h"
#include "Timer.h"
#include "EEPROM.h"

#define _FAN_Init()     TRISBbits.TRISB0 = 0
#define _FAN_Off()      LATBbits.LATB0 = 0
#define _FAN_On()       LATBbits.LATB0 = 1
#define _FAN_Toogle()     LATBbits.LATB0 ^= 1

#define _BUZZ_Init()    TRISDbits.TRISD1 = 0
#define _BUZZ_On()      LATDbits.LATD1 = 1;
#define _BUZZ_Off()     LATDbits.LATD1 = 0;
#define _BUZZ_Toogle()  LATDbits.LATD1 ^= 1;
#define _BUZZ_Stat      LATDbits.LATD1

#define _RELAY_Init()   TRISEbits.TRISE4 = 0
#define _RELAY_On()     LATEbits.LATE4 = 1
#define _RELAY_Off()    LATEbits.LATE4 = 0

#define _INTERRUPT_PIN_HIGH PORTEbits.RE8
extern inline void _EXT_INTERRUPT_Init(void);

#define _INVERTER_MODE  1
#define _MAINS_MODE     2
#define _PV_MODE        3
#define _ERROR          4

#define _UPS_EN         1
#define _INV_EN         2

#define ON              1
#define OFF             0


#define _SW_Init()      TRISDbits.TRISD0 = 1; TRISEbits.TRISE5 = 1
#define _CALIB_EN()     TRISDbits.TRISD1 = 1
#define _CALIB_DIS()    TRISDbits.TRISD1 = 0
#define _SW_ON_OFF         PORTDbits.RD0
#define _SW_UPS_INV        PORTEbits.RE5
#define _LEFT              PORTEbits.RE5
#define _RIGHT             PORTDbits.RD1
#define _ENTER             PORTDbits.RD0

extern void SYSTEM_Init(void);
extern void SYSTEM_Error(void);