#include "adc.h"

void adc_init(){
    ADCON1bits.ADON = 0;
    ADCON1bits.ADSIDL = 0;                                                      //Module works in idle mode
    ADCON1bits.FORM0 = ADCON1bits.FORM1 = 0;                                    // Integer output
    ADCON1bits.SSRC = 0b111;                                                    //Auto convert
    ADCON1bits.SIMSAM = 1;                                                      //Simultanious sampling
    ADCON1bits.ASAM = 1;                                                        //Sampling begins when conversion finish
    
    ADCON2bits.VCFG = 0x0;                                                      //VDD and VSS as reference
    ADCON2bits.CSCNA = 0;                                                       //Input scan bit
    ADCON2bits.SMPI = 0x3;                                                      //Interup on completion of 4th cycle
    ADCON2bits.BUFM = 0;                                                        //Single 16bit buffer
    ADCON2bits.ALTS = 0;                                                        //Always use MUX A
    ADCON2bits.CHPS = 0b11;                                                     //Sample all in parallel
    
    ADCON3bits.SAMC = 0b11111;                                                  //0TAD for auto sampling
    ADCON3bits.ADRC = 0;                                                        //Primary clock for ADC
    ADCON3bits.ADCS = 0b00001;                                                 //0Tcy for conversion
    
    ADCHSbits.CH0SA = 0b0001;                                                   //SH0 Input as AN1
    ADCHSbits.CH0NA = 0;                                                        //SH0 neg input as Vref neg      
    ADCHSbits.CH123SA = 1;                                                      //SH1, SH2, SH3 Input as AN3, AN4, AN5
    ADCHSbits.CH123NA = 0b00;                                                   //SH1, SH2, SH3 Input neg as Vref neg
    
    ADPCFG = 0x00;                                                              //Setting all input as analog
    adc_set_ch(0x01);
    ADCON1bits.ADON = 1;                                                        //Start adc module
    IFS0bits.ADIF = 0;
    IEC0bits.ADIE = 1;
}

void adc_set_ch(char ch){
    ADCHSbits.CH0SA = ch & 0x0f;
}