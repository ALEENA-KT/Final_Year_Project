
#include "System.h"

// DSPIC30F2010 Configuration Bit Settings

// 'C' source line config statements

// FOSC
#pragma config FPR = XT_PLL8            // Primary Oscillator Mode (XT w/PLL 8x)
#pragma config FOS = PRI                // Oscillator Source (Primary Oscillator)
#pragma config FCKSMEN = CSW_FSCM_OFF   // Clock Switching and Monitor (Sw Disabled, Mon Disabled)

// FWDT
#pragma config FWPSB = WDTPSB_16        // WDT Prescaler B (1:16)
#pragma config FWPSA = WDTPSA_512       // WDT Prescaler A (1:512)
#pragma config WDT = WDT_OFF            // Watchdog Timer (Disabled)

// FBORPOR
#pragma config FPWRT = PWRT_OFF         // POR Timer Value (Timer Disabled)
#pragma config BODENV = NONE            // Brown Out Voltage (Reserved)
#pragma config BOREN = PBOR_OFF         // PBOR Enable (Disabled)
#pragma config LPOL = PWMxL_ACT_HI      // Low-side PWM Output Polarity (Active High)
#pragma config HPOL = PWMxH_ACT_HI      // High-side PWM Output Polarity (Active High)
#pragma config PWMPIN = RST_IOPIN       // PWM Output Pin Reset (Control with PORT/TRIS regs)
#pragma config MCLRE = MCLR_DIS         // Master Clear Enable (Disabled)

// FGS
#pragma config GWRP = GWRP_OFF          // General Code Segment Write Protect (Disabled)
#pragma config GCP = CODE_PROT_OFF       // General Segment Code Protection (Enabled)

// FICD
#pragma config ICS = PGD                // Comm Channel Select (Use PGC/EMUC and PGD/EMUD)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.


void SYSTEM_Init(void){
    unsigned char _error;
    _FAN_Init();
    _BUZZ_Init();
    _RELAY_Init();
    ADPCFG = 0x00;
    _BUZZ_Off();
    _RELAY_Off();
    _FAN_Off();
    //Global delay
    __delay_ms(500);
    _BUZZ_On();
    __delay_ms(50);
    _BUZZ_Off();
    _RELAY_Off();
    I2C_Init();
    __delay_ms(10);
    _error = LCD_Init();
    if(_error == I2C_ERROR){
        SYSTEM_Error();
    }
    __delay_ms(50);
    PWM_Init();
    _disable_PWM();
    adc_init();
    adc_set_ch(0x01);
    Timer_1_Init();
    _EXT_INTERRUPT_Init();
    _FAN_On();
    for(_error = 0; _error < 10; _error ++){
        _BUZZ_On();
        __delay_ms(25);
        _BUZZ_Off();
        __delay_ms(25);
    }
    _FAN_Off();
    _SW_Init();
}

void SYSTEM_Error(void){
    for(;;){
        _BUZZ_On();
        __delay_ms(100);
        _BUZZ_Off();
        __delay_ms(100);
    }
}

inline void _EXT_INTERRUPT_Init(void){
    TRISEbits.TRISE8 = 1;
    INTCON2bits.INT0EP = 0;
    IEC0bits.INT0IE = 0;
}