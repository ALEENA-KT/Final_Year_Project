#include "pwm.h"

void PWM_Init(){
    TRISEbits.TRISE0 = TRISEbits.TRISE1 = TRISEbits.TRISE2 = TRISEbits.TRISE3 = 0;
    LATEbits.LATE0 = LATEbits.LATE1 = LATEbits.LATE2 = LATEbits.LATE3 = 0;
    
    PTCONbits.PTOPS = 0b00; //Post scale to 0
    PTCONbits.PTCKPS = 0b00; //Prescale to 0
    PTCONbits.PTMOD = 0b10; //Single updation up down mode
    
    PTMR = 0x0000;  //Count start from zero
    
    PTPER = 0x018f; //Period set to 20Khz
    
    PWMCON1bits.PMOD2 = 0; // PWM in complimentary mode
    PWMCON1bits.PMOD1 = 0; // PWM in complimentary mode
    
    PWMCON1bits.PEN2L = 1; // PWM Low pin enabled (direction control later?)
    PWMCON1bits.PEN1L = 1; // PWM Low pin enabled
    
    PWMCON1bits.PEN2H = 1; // PWM High pin is enabled
    PWMCON1bits.PEN1H = 1; // PWM High pin is enabled
    
    DTCON1bits.DTAPS = 0;  //DeadTime pre-scaler
    DTCON1bits.DTA = 0x1c;   //DeadTime value for 4 us. 
    
    PDC1 = 0x0000;
    PDC2 = 0x0000;
    
    IFS2bits.PWMIF = 0;
    IEC2bits.PWMIE = 0;
    
    PTCONbits.PTEN = 1;
}

void PWM_Duty(unsigned int _duty_1, unsigned int _duty_2){
    //Do something
    PDC1 = _duty_1;
    PDC2 = _duty_2;
    return;
}

void _disable_PWM(void){
    //Stop timer module
    Timer_1_Stop();
    PDC2 = 0x0000;
    PDC1 = 0x0000;
    PWMCON1bits.PMOD2 = 1;
    PWMCON1bits.PMOD1 = 1;
    PWMCON1bits.PEN2H = 0;
    PWMCON1bits.PEN1H = 0;
    PWMCON1bits.PEN1L = 0;
    PWMCON1bits.PEN2L = 0;
    LATEbits.LATE0 = LATEbits.LATE2 = 0;
    LATEbits.LATE1 = LATEbits.LATE3 = 0;
    return;
}

void _enable_SPWM(void){
    PWMCON1bits.PMOD2 = 0;
    PWMCON1bits.PMOD1 = 0;
    PWMCON1bits.PEN2H = 1;
    PWMCON1bits.PEN1H = 1;
    PWMCON1bits.PEN1L = 1;
    PWMCON1bits.PEN2L = 1;
    IFS2bits.PWMIF = 0;
//    IEC2bits.PWMIE = 1;
    PDC2 = 0x0000;
    PDC1 = 0x0000;
    
    //Initializing timer module
    Timer_1_Run();
    return;
}

void _enable_CHPWM(void){
    PWMCON1bits.PMOD2 = 1;
    PWMCON1bits.PMOD1 = 1;
    PWMCON1bits.PEN2H = 1;
    PWMCON1bits.PEN1H = 1;
    PWMCON1bits.PEN1L = 0;
    PWMCON1bits.PEN2L = 0;
    LATEbits.LATE0 = LATEbits.LATE2 = 0;
    IFS2bits.PWMIF = 0;
//    IEC2bits.PWMIE = 0;
    PDC2 = 0x0000;
    PDC1 = 0x0000;
    return;
}
//
//void _disable_CHPWM(void){
//    PWMCON1bits.PMOD2 = 1;
//    PWMCON1bits.PMOD1 = 1;
//    PWMCON1bits.PEN2H = 0;
//    PWMCON1bits.PEN1H = 0;
//    LATEbits.LATE0 = LATEbits.LATE2 = 0;
//    PDC2 = 0x0000;
//    PDC1 = 0x0000;
//}