/*
 * File:   Main.c
 * 
 *
 */
#include "System.h"
#include "Param.h"

//ADC Params and setting
void __attribute__ ((interrupt, no_auto_psv)) _ADCInterrupt(void);  // ISR Service for continous ADC Sampling
#define _NTC_Channel 0x01                                           //Channel for reading NTC Voltage
#define _BATV_Channel 0x02                                          //Channel for reading Battery voltage
unsigned char _channel = _NTC_Channel;                              //Predefining ADC channel to NTC
unsigned char _circular_buffer[10];                                 //Circular buffer for running average algorithm
//Temperature params
unsigned char _count_temperature;
unsigned int _array_temperature[10];
unsigned int _sum_temperature;
unsigned int _result_temperature;
//long _Resistance;
//unsigned int _Temperature;
//Battery params
unsigned char _count_vbat;
//unsigned int _array_vbat[10];
unsigned int _sum_vbat;
unsigned int _result_vbat;
unsigned int _Vbat = 12000;
unsigned int _Vbat_Calib;
unsigned int _Low_Battery_Counter = 0;
unsigned int _Battery_Warning_Counter = 0;
uint16_t _LOW_BAT_TRAP;
uint16_t _LOW_BAT_WARNING;
uint16_t _BAT_HIGH;
uint16_t _Vbat_Roundup;
//AC Input param
unsigned char _count_acInput;
unsigned int _array_acInput[10];
unsigned int _sum_acInput;
unsigned int _result_acInput;
unsigned int _acInput_low_peak;
unsigned int _acInput_high_peak;
unsigned int _acInput_buffer;
unsigned char _acInput_stat;
unsigned char _acInput_RMS;
unsigned int _array_acInput_avg[10];
unsigned int _count_acInput_avg;
unsigned int _acInput_AVG;
unsigned int _sum_acInput_avg;
uint16_t _acInput_calib;
uint16_t _acFail_Counter = 0;
//AC Output param
unsigned char _count_acOutput;
unsigned int _array_acOutput[10];
unsigned int _sum_acOutput;
unsigned int _result_acOutput;
unsigned int _acOutput_low_peak;
unsigned int _acOutput_high_peak;
unsigned int _acOutput_buffer;
unsigned char _acOutput_stat;
unsigned char _acOutput_RMS;
unsigned int _array_acOutput_avg[10];
unsigned int _count_acOutput_avg;
unsigned int _acOutput_AVG;
unsigned int _sum_acOutput_avg;
uint16_t _acOutput_calib;
//AC Current param
unsigned char _count_acCurrent;
unsigned int _array_acCurrent[10];
unsigned int _sum_acCurrent;
unsigned int _result_acCurrent;
unsigned int _acCurrent;
unsigned int _acCurrent_low_peak;
unsigned int _acCurrent_high_peak;
unsigned int _acCurrent_peak;
unsigned int _acCurrent_buffer;
unsigned char _acCurrent_stat;
unsigned char _acCurrent_RMS;
unsigned int _array_acCurrent_avg[10];
unsigned int _count_acCurrent_avg;
unsigned int _acCurrent_AVG;
unsigned int _sum_acCurrent_avg;
//int _acCurrent_calib;
//Load param
//uint16_t _Power_Max;
uint16_t _Output_Load;
uint16_t _Power_calib;
//uint16_t _Surge_Max;
uint16_t _PowerOutput_Max;
//uint16_t _SurgeOutput_Max;
uint16_t _Overload_Cnt = 0;

//Display parameters
void flush_dsp(void);
void fn_dsp(unsigned char);
#define _dsp_limit 4
unsigned char _dsp_data[5];
uint16_t _Display_Type;
void intDisplay(uint16_t *_recieved_value);

//Short circuit detection
void __attribute__ ((interrupt, no_auto_psv)) _INT0Interrupt(void);
uint16_t _sc_trap = 0;
uint16_t _sc_counter = 0;

//PWM Params
//Sine table for PWM Generation
uint8_t _PWM_Sine_lt[40] = {
    16,32,47,62,77,91,105,118,130,142,152,162,171,178,185,190,194,198,199,200,
    200,199,198,194,190,185,178,171,162,152,142,130,118,105,91,77,62,47,32,16
};
uint16_t _PWM_DUTY_MAX;
//#define _PWM_DUTY_MIN 80
#define _PWM_DUTY_MIN 10
uint16_t _PWM_Counter = 0;
uint8_t _PWM_State = 0;
uint8_t _INP_State = 0;
uint8_t _INP_Counter = 0;
uint16_t _PWM_Duty = 0;
int _Load_Regulation = 80;

//Timer param
void __attribute__ ((interrupt, no_auto_psv)) _T1Interrupt(void);

//Switch param
#define _DEBOUNCE_LIMIT 100
#define _THRESHOLD_LIMIT 50
void _Switch_Stat(void);
uint8_t _OnOff_Cnt = 0;
uint8_t _UpsInv_Cnt = 0;
uint8_t _ACOUT_Mask = 0;
uint8_t _Read_Switch(void);

//Common param
uint8_t _Mode;
uint8_t _Phase_acOutput;
uint8_t _Phase_errorCnt = 0;
uint16_t _OutputVoltage_errorCnt = 0;
uint16_t _acCurrent_errorCnt = 0;
void _Traps(uint8_t);
//uint16_t _beep = 0;
uint16_t _InputVoltage_errorCnt = 0;
#define _PBCN 500
uint16_t _acFail;
uint8_t _UPS_INV = _INV_EN;
#define _SC_Check_Enable()  IEC0bits.INT0IE = 1
#define _SC_Check_Disable()  IEC0bits.INT0IE = 0
//#define _EN_FBC
uint8_t _INV_Stat = OFF;
uint16_t _return_value;
uint8_t _total_restart_time;
uint8_t _seconds;

//Warning param
uint8_t _warning = 0;
#define _ALERT_LOW_BAT      1
#define _ALERT_OVERLOAD     2
#define _ALERT_MAINS_HIGH   3
#define _ALERT_MAINS_LOW    4
#define _ALERT_TEMP         5
#define _ALERT_MAINS_FAIL   6
#define _ALERT_BATTERY_FILL 7


void main(void) {
    unsigned int i;
    unsigned char _dsp_cnt = 0;
    unsigned int _event_low = 0;
    unsigned int _event_display = 0;
//    uint8_t _sw_fb = 0;
    
    //Global flush
    for(i = 0; i < 10; i ++) _array_temperature[i] = _array_acInput[i] = 
            _array_acOutput[i] = _array_acCurrent[i] = _array_acOutput_avg[i] = _array_acInput_avg[i] = _array_acCurrent_avg[i] = 0;
    _sum_temperature = _sum_vbat = _sum_acInput = _sum_acOutput = _sum_acCurrent = _sum_acOutput_avg = _sum_acInput_avg = _sum_acCurrent_avg = 0;
    _count_temperature =_count_vbat = _count_acInput = _count_acOutput = _count_acCurrent = _count_acOutput_avg = _count_acInput_avg = _count_acCurrent_avg = 0;
    _circular_buffer[0] = 1; _circular_buffer[1] = 2; _circular_buffer[2] = 3; _circular_buffer[3] = 4; _circular_buffer[4] = 5;
    _circular_buffer[5] = 6; _circular_buffer[6] = 7; _circular_buffer[7] = 8; _circular_buffer[8] = 9; _circular_buffer[9] = 0;
//    flush_dsp();
    _Mode = _MAINS_MODE;
    _InputVoltage_errorCnt = 0;
    _acFail  = _PBCN;
    
    SYSTEM_Init();
    
    //Calibration data aquisition
    
    _Vbat_Calib = 105; 
    _acInput_calib = 20;
    _acOutput_calib = 20;
    _Power_calib = 40;
    _PWM_DUTY_MAX = 325;
    _Display_Type = 1;
    _PowerOutput_Max = 800;
//        _Surge_Max = 10;
    _LOW_BAT_TRAP = 10500;
    _BAT_HIGH = 13500;
    _LOW_BAT_WARNING = _LOW_BAT_TRAP + 400;
    
    for(;;){
        //Calculating RMS Value
        //RMS Input voltage calculation
        if(_result_acInput > 532){
            if(_acInput_stat){
                _acInput_stat = 0;
                _acInput_high_peak = 0;
                _array_acInput_avg[_count_acInput_avg] = _acInput_low_peak;
                _sum_acInput_avg += _acInput_low_peak;
                _sum_acInput_avg -= _array_acInput_avg[_circular_buffer[_count_acInput_avg]];
                _count_acInput_avg ++;
                if(_count_acInput_avg == 10) _count_acInput_avg = 0;
                _acInput_AVG = (_sum_acInput_avg / 9) - _acInput_calib;
                _acInput_low_peak = 0;
                
                if(_acInput_AVG > 100)  {
                    _InputVoltage_errorCnt = 0; 
                    if(_acFail) _acFail --;
                }
                
                //Phase correction with positive cycle
//                _PWM_State = 1;
                if(!_PWM_State){
                    
                    _INP_Counter = 40 - _PWM_Counter;
                    _PWM_Counter = 0;
                    _PWM_State = 1;
                }
                
            }
            _acInput_buffer = _result_acInput - 512;
            if(_acInput_buffer > _acInput_high_peak)    _acInput_high_peak = _acInput_buffer;
            
            //Ac mains fail detection
            if(_acInput_buffer < 40){
                _InputVoltage_errorCnt ++;
                if(_InputVoltage_errorCnt > 90){
                        _InputVoltage_errorCnt = 91;
                        _acInput_AVG = 0;
                        _acFail = _PBCN;
                }
            }
        }
        else if(_result_acInput < 492){
            if(_acInput_stat == 0){
                _acInput_stat = 1;
                _acInput_low_peak = 0;
                _array_acInput_avg[_count_acInput_avg] = _acInput_high_peak;
                _sum_acInput_avg += _acInput_high_peak;
                _sum_acInput_avg -= _array_acInput_avg[_circular_buffer[_count_acInput_avg]];
                _count_acInput_avg ++;
                if(_count_acInput_avg == 10) _count_acInput_avg = 0;
                _acInput_AVG = _sum_acInput_avg / 9 - _acInput_calib;
                _acInput_high_peak = 0;
                
                if(_acInput_AVG > 100)  _InputVoltage_errorCnt = 0;
                
                //Phase correction with negative cycle
//                _PWM_State = 0
                if(_PWM_State){
                    
                    _INP_Counter = 40 - _PWM_Counter;
                    _PWM_Counter = 0;
                    _PWM_State = 0;
                }
            }
            _acInput_buffer = (512 - _result_acInput);
            if(_acInput_buffer > _acInput_low_peak)    _acInput_low_peak = _acInput_buffer;
            
            //Ac mains fail detection
            if(_acInput_buffer < 40){
                _InputVoltage_errorCnt ++;
                if(_InputVoltage_errorCnt > 90){
                        _InputVoltage_errorCnt = 91;
                        _acInput_AVG = 0;
                        _acFail = _PBCN;
                }
            }
        }
        else{
            //Mains fail detection with 25Khz / 10ms time width
            _InputVoltage_errorCnt ++;
            if(_InputVoltage_errorCnt > 90){
                    _InputVoltage_errorCnt = 91;
                    _acInput_AVG = 0;
                    _acFail = _PBCN;
            }
        }
        
        
        //RMS Output voltage calcualtion
        if(_result_acOutput > 532){
            if(_acOutput_stat){
                _acOutput_stat = 0;
                _acOutput_high_peak = 0;
                _array_acOutput_avg[_count_acOutput_avg] = _acOutput_low_peak;
                _sum_acOutput_avg += _acOutput_low_peak;
                _sum_acOutput_avg -= _array_acOutput_avg[_circular_buffer[_count_acOutput_avg]];
                _count_acOutput_avg ++;
                if(_count_acOutput_avg == 10) _count_acOutput_avg = 0;
                _acOutput_AVG = (_sum_acOutput_avg / 9) - _acOutput_calib;
                
                //regulation
                if(_Mode == _INVERTER_MODE){
                    if(_acOutput_AVG < 220){
                        _Load_Regulation ++;
                    }
                    else if(_acOutput_AVG > 221){
                        _Load_Regulation --;
                    }
                    
//                    //Low voltage trap reset
//                    if(_acOutput_AVG > 80){
//                        _OutputVoltage_errorCnt = 0;
//                    }
                }
            }
            _acOutput_buffer = _result_acOutput - 512;
            if(_acOutput_buffer > _acOutput_high_peak)    _acOutput_high_peak = _acOutput_buffer;
            _Phase_acOutput = 0;
        }
        else if(_result_acOutput < 492){
            if(_acOutput_stat == 0){
                _acOutput_stat = 1;
                _acOutput_low_peak = 0;
                _array_acOutput_avg[_count_acOutput_avg] = _acOutput_high_peak;
                _sum_acOutput_avg += _acOutput_high_peak;
                _sum_acOutput_avg -= _array_acOutput_avg[_circular_buffer[_count_acOutput_avg]];
                _count_acOutput_avg ++;
                if(_count_acOutput_avg == 10) _count_acOutput_avg = 0;
                _acOutput_AVG = (_sum_acOutput_avg / 9) - _acOutput_calib;
            }
            _acOutput_buffer = (512 - _result_acOutput);
            if(_acOutput_buffer > _acOutput_low_peak)    _acOutput_low_peak = _acOutput_buffer;
            _Phase_acOutput = 1;
        }
        else{
            //Low output voltage trap
            if(_Mode == _INVERTER_MODE){
#ifdef _EN_FBC
                    _OutputVoltage_errorCnt ++;   //Uncomment this ASAP
#endif
                if(_OutputVoltage_errorCnt > 10000){
                    _Traps(3);
                }
            }
        }
        //RMS Current calculation
        if(_result_acCurrent > 512){
            if(_acCurrent_stat){
                _acCurrent_stat = 0;
                _acCurrent_peak = _acCurrent_low_peak;
                _acCurrent_high_peak = 0;
                
                _array_acCurrent_avg[_count_acCurrent_avg] = _acCurrent_peak;
                _sum_acCurrent_avg += _acCurrent_peak;
                _sum_acCurrent_avg -= _array_acCurrent_avg[_circular_buffer[_count_acCurrent_avg]];
                _count_acCurrent_avg ++;
                if(_count_acCurrent_avg == 10) _count_acCurrent_avg = 0;
                _acCurrent_AVG = (_sum_acCurrent_avg / 9);
                _acCurrent_errorCnt = 0;
            }
            _acCurrent_buffer = _result_acCurrent - 512;
            if(_acCurrent_buffer > _acCurrent_high_peak)    _acCurrent_high_peak = _acCurrent_buffer;
        }
        else if(_result_acCurrent < 512){
            if(_acCurrent_stat == 0){
                _acCurrent_stat = 1;
                _acCurrent_peak = _acCurrent_high_peak;
                _acCurrent_low_peak = 0;
                
                _array_acCurrent_avg[_count_acCurrent_avg] = _acCurrent_peak;
                _sum_acCurrent_avg += _acCurrent_peak;
                _sum_acCurrent_avg -= _array_acCurrent_avg[_circular_buffer[_count_acCurrent_avg]];
                _count_acCurrent_avg ++;
                if(_count_acCurrent_avg == 10) _count_acCurrent_avg = 0;
                _acCurrent_AVG = (_sum_acCurrent_avg / 9);
                _acCurrent_errorCnt = 0;
            }
            _acCurrent_buffer = (512 - _result_acCurrent);
            if(_acCurrent_buffer > _acCurrent_low_peak)    _acCurrent_low_peak = _acCurrent_buffer;
        }
        _acCurrent_errorCnt ++;
        if(_acCurrent_errorCnt > 10000){
            _acCurrent_errorCnt = 0;
            _acCurrent_AVG = 0;
        }
        
        
        //Inverter switch force stop
        if(!_INV_Stat){
//            _disable_PWM();
            _acFail = _PBCN;
            _acInput_buffer = 200;
            _BUZZ_Off();
            _CALIB_EN();
            _dsp_cnt = 0;
        }
//        else{
//            //UPS and INVERTER mode force start
////            if(_UPS_INV == _UPS_EN){
//                if((_acInput_AVG > _UPS_MODE_AC_HIGH_CUT)){ 
//                    _acFail = _PBCN; 
//                    _warning = _ALERT_MAINS_HIGH;
//                }
//                else if((_acInput_AVG < _UPS_MODE_AC_LOW_CUT)){
//                    _acFail = _PBCN;
//                    if(_acInput_AVG > _INV_MODE_AC_LOW_CUT) _warning = _ALERT_MAINS_LOW;
//                }
//                
//                
////            }
////            else{
////                if(_acInput_AVG < _INV_MODE_AC_LOW_CUT){
////                    _acFail = _PBCN;
//////                    _warning = _ALERT_MAINS_LOW;
////                }
////            }
//        }
        
        //Change over 
        if(_Mode == _MAINS_MODE){
            if(!_acFail){
                _disable_PWM();
                _Mode = _INVERTER_MODE;
                _CALIB_DIS();
                _BUZZ_On();
                _disable_PWM();
                _event_low = _event_display = 0; 
                __delay_ms(5);
                _Load_Regulation = 220;
                _SC_Check_Enable();
                _PWM_Counter = 0;
                _enable_SPWM();
            }
        }
        else if(_Mode == _INVERTER_MODE){
            if(_acFail){
//                if(_acInput_buffer > 100){
                    _SC_Check_Disable();
                    _disable_PWM();
                    _Mode = _MAINS_MODE;
                    _BUZZ_On();
                    _disable_PWM();
                    _event_low = _event_display = 0; 
                    __delay_ms(1); //Please use delay, Otherwise inverter will blow
                    _disable_PWM();
//                }
            }
            
            
//            if(_PWM_DUTY_MAX > 325) _PWM_DUTY_MAX = 325;
            if(_Load_Regulation > 220) _Load_Regulation = 220;
            else if(_Load_Regulation < _PWM_DUTY_MIN) _Load_Regulation = _PWM_DUTY_MIN;
        
            _PWM_Duty = _acInput_buffer * _Load_Regulation;
        
            _PWM_Duty /= 80;

            if(_PWM_Duty > 797) _PWM_Duty = 797;

            if(_PWM_State){
                PWM_Duty(_PWM_Duty,0);
            }
            else{
                PWM_Duty(0,_PWM_Duty);
            }
        }
        
        //Start of display event timer
        _event_low ++;
        if(_event_low > 1000){
            _event_low = 0;
            _event_display ++;
            if(_BUZZ_Stat && ((_warning == 0) || (_warning == _ALERT_MAINS_FAIL))) _event_display ++;
            
            //Medium speed UUT
            _Switch_Stat();
            
            //Calculating vBat
            _Vbat = (_result_vbat * _Vbat_Calib) / 4;
            
            //Calculating Output current
            _Output_Load = (unsigned int)((_acCurrent_AVG * _Power_calib) / 10);
            
            //Calculating DC Current
//            _Vbat_Roundup = (uint16_t)(_Vbat / 1000);
//            _DC_Current = (uint16_t)((_acCurrent_AVG * _acInput_AVG) / _Vbat_Roundup);
            
            
            //Temperature check
            if(_result_temperature > 485) _FAN_On();
            else if(_result_temperature < 474) _FAN_Off();
            
            //Param to check when inverter working
            if(_INV_Stat){
                //Setting warning for input fail
                if(_Mode == _INVERTER_MODE){
                    
//                    if(_Output_Load > (_PowerOutput_Max + _OUTPUT_SURGE_MAXIMUM_VALUE)){
//                        _Traps(6);
//                    }
                    if(_Output_Load > (_PowerOutput_Max + _OUTPUT_SURGE_MAXIMUM_VALUE)){
//                        _beep = 1;
                        _Overload_Cnt = _Overload_Cnt + 5;
//                        _warning = _ALERT_OVERLOAD;
                    }
                    else if(_Output_Load > _PowerOutput_Max){
//                        _beep = 1;
                        _Overload_Cnt ++;
//                        _warning = _ALERT_OVERLOAD;
                    }
                    else if(_Overload_Cnt){  
//                        _beep = 0;
                        _Overload_Cnt --;
                        if(_Overload_Cnt) _Overload_Cnt --;
                        if(_Overload_Cnt) _Overload_Cnt --;
                    }

                    if(_Overload_Cnt > 25){
                        _warning = _ALERT_OVERLOAD;
//                        _beep = 1;
                    }
//                    else if(_Overload_Cnt < 5){
////                        _beep = 0;
//                    }
                    
                    if(_Overload_Cnt > 50){
                        _Traps(7);
                    }
                }
                
                
                //Temperature check
                if(_result_temperature > 778) _Traps(8);
                else if(_result_temperature > 749){ 
//                    _beep = 1;
                    _warning = _ALERT_TEMP;
                   
                }
//                else _beep = 0;
                
                //Battery voltage check
                if(_Vbat < 9000)    _Traps(4);
                else if(_Vbat < _LOW_BAT_TRAP){
//                    _beep = 1;
                    _Low_Battery_Counter ++;
                    if(_Low_Battery_Counter > 500) _Traps(5);
                } 
                else if(_Vbat < _LOW_BAT_WARNING){
                    _Battery_Warning_Counter ++;
                    if(_Battery_Warning_Counter > 500) _warning = _ALERT_LOW_BAT;
//                    _beep = 1;
                    _Low_Battery_Counter = 0;
                }
                else{
                    _Low_Battery_Counter = 0;
                    _Battery_Warning_Counter = 0;
                }
                
            }
            else{
                _BUZZ_Off();
            }
            
//            if(_beep){
//                
//            }
            
            //Display control and low speed fn
            if((_event_display > 100)){
                
                
                
                _event_display = 0;
                fn_dsp(_dsp_cnt);
                _dsp_cnt ++;
                if(_dsp_cnt > _dsp_limit) _dsp_cnt = 0;

                //Buzzer control
                if((_warning == _ALERT_OVERLOAD) || (_warning == _ALERT_TEMP) || (_warning == _ALERT_LOW_BAT)){
                   //_BUZZ_Toogle();
                }
                else _BUZZ_Off();

                //Low speed UUT
                if(_total_restart_time){
                    _seconds ++;
                    if(_seconds > 20) {
                        _total_restart_time = 0;
                        Eeprom_WriteWord(_RESTART_ADDRESS ,_total_restart_time);
                        _seconds = 0;
                    }
                }
                
            }
            
            
        }
        //Clearing buffers after each cycle
    }
    return;
}

void __attribute__ ((interrupt, no_auto_psv)) _ADCInterrupt(void){
    if(IFS0bits.ADIF){
        IEC0bits.ADIE = 0;
        IFS0bits.ADIF = 0;
        if(_channel == _NTC_Channel){
            _channel = _BATV_Channel;
            adc_set_ch(_BATV_Channel);
            _array_temperature[_count_temperature] = ADCBUF0;
            _sum_temperature += _array_temperature[_count_temperature];
            _sum_temperature -= _array_temperature[_circular_buffer[_count_temperature]];
            _count_temperature ++;
            if(_count_temperature == 10) _count_temperature = 0;
            _result_temperature = _sum_temperature / 9;

        }
        else{
            _channel = _NTC_Channel;
            adc_set_ch(_NTC_Channel);
//            _array_vbat[_count_vbat] = ADCBUF0;
//            _sum_vbat += _array_vbat[_count_vbat];
//            _sum_vbat -= _array_vbat[_circular_buffer[_count_vbat]];
            _sum_vbat += ADCBUF0;
            _count_vbat ++;
            if(_count_vbat == 10){ 
                _count_vbat = 0;
                _result_vbat = _sum_vbat / 9;
                _sum_vbat = 0;
            }
        }
         _array_acInput[_count_acInput] = ADCBUF1;
        _sum_acInput += _array_acInput[_count_acInput];
        _sum_acInput -= _array_acInput[_circular_buffer[_count_acInput]];
        _count_acInput ++;
        if(_count_acInput == 10) _count_acInput = 0;
        _result_acInput = _sum_acInput / 9;
        
        
        _array_acOutput[_count_acOutput] = ADCBUF3;
        _sum_acOutput += _array_acOutput[_count_acOutput];
        _sum_acOutput -= _array_acOutput[_circular_buffer[_count_acOutput]];
        _count_acOutput ++;
        if(_count_acOutput == 10) _count_acOutput = 0;
        _result_acOutput = _sum_acOutput / 9;
        

        _array_acCurrent[_count_acCurrent] = ADCBUF2;
        _sum_acCurrent += _array_acCurrent[_count_acCurrent];
        _sum_acCurrent -= _array_acCurrent[_circular_buffer[_count_acCurrent]];
        _count_acCurrent ++;
        if(_count_acCurrent == 10) _count_acCurrent = 0;
        _result_acCurrent = _sum_acCurrent / 9;
        
        IEC0bits.ADIE = 1;
    }
    return;
}

void __attribute__ ((interrupt, no_auto_psv)) _T1Interrupt(void){
    if(IFS0bits.T1IF){
        IEC0bits.T1IE = 0;
        T1CONbits.TON = 0;
        IFS0bits.T1IF = 0;
        _PWM_Counter ++;
        if(_PWM_Counter >= 40){
            _PWM_Counter = 0;
//            _PWM_State ^= 1;
        }
        
//        if(_PWM_DUTY_MAX > 325) _PWM_DUTY_MAX = 325;
//        if(_Load_Regulation > _PWM_DUTY_MAX) _Load_Regulation = _PWM_DUTY_MAX;
//        else if(_Load_Regulation < _PWM_DUTY_MIN) _Load_Regulation = _PWM_DUTY_MIN;
        
        //Phase correction or FB check
#ifdef _EN_FBC
        if(_PWM_Counter == 20){
            if(_Load_Regulation > 100){
                if(_PWM_State){
                    if(_Phase_acOutput){
                        _Phase_errorCnt ++;
                        if(_Phase_errorCnt > 5){
                            PWM_Duty(0,0);
                            _Traps(2);
                        } 
                    }
                    else{
                        _Phase_errorCnt = 0;
                    }
                }
            }
        }
#endif
//        _PWM_Duty = _PWM_Sine_lt[_PWM_Counter] * _Load_Regulation;
//        
//        _PWM_Duty = _acInput_buffer * _Load_Regulation;
//        
//        _PWM_Duty /= 80;
//        
//        if(_PWM_Duty > 797) _PWM_Duty = 797;
//        
//        if(_PWM_State){
//            PWM_Duty(_PWM_Duty,0);
//        }
//        else{
//            PWM_Duty(0,_PWM_Duty);
//        }
        TMR1 = 0x00;
        IEC0bits.T1IE = 1;
        T1CONbits.TON = 1;
    }
}

void __attribute__ ((interrupt, no_auto_psv)) _INT0Interrupt(void){
    if(IFS0bits.INT0IF){
        IEC0bits.INT0IE = 0;
        IFS0bits.INT0IF = 0;
        PWM_Duty(0,0);
        _sc_counter ++;
        if(_sc_counter > 3){
            _sc_counter = 0;
            _BUZZ_On();
            LCD_Clear();
            I2C_Init();
            LCD_Set_Cursor(1,1);
            LCD_Write_String("SHORT CIRCUIT");
            __delay_ms(1000);
            _sc_trap ++;
            if(_sc_trap > 3){
                _Traps(1);
            }
            _BUZZ_Off();
            __delay_ms(1000);
            _Load_Regulation = 80;
        }
        IEC0bits.INT0IE = 1;
    }
    return;
}

void fn_dsp(unsigned char _dsp_cnt){
    if(_INV_Stat){
            flush_dsp();
//            LCD_Clear();
            Backlight();
            LCD_Set_Cursor(1,1);
            LCD_Write_String("                ");
            LCD_Set_Cursor(2,1);
            LCD_Write_String("                ");
            LCD_Set_Cursor(1,1);
            ////////
//            _dsp_cnt = 0;
            ////////
            switch(_dsp_cnt){
                case 0:
                    //Ultra low speed reset
                    _sc_trap = 0;
                    _sc_counter = 0;
                    LCD_Write_String("GRID INVERTER");
                    LCD_Set_Cursor(2,1);
                    LCD_Write_String("POW:");
                    intToStr(_PowerOutput_Max, &_dsp_data, 0);
                    LCD_Write_String(_dsp_data);
                    LCD_Write_String("VA");
                    break;
                case 1:

                    LCD_Write_String("BAT V:");
                    intToStr((uint8_t)(_Vbat / 1000), &_dsp_data, 0);
                    LCD_Write_String(_dsp_data);
                    LCD_Write_String(".");
                    flush_dsp();
                    intToStr((uint8_t)((_Vbat % 1000) / 100), &_dsp_data, 0);
                    LCD_Write_String(_dsp_data);
                    LCD_Write_String("V");
                    flush_dsp();
                    LCD_Set_Cursor(2,1);
                    LCD_Write_String("LOAD:");
                    intToStr(_Output_Load, &_dsp_data, 0);
                    LCD_Write_String(_dsp_data);
                    LCD_Write_String("VA");
                    break;
                case 2:
                    LCD_Write_String("AC INPUT:");
                    /*if(_acInput_AVG > 40)*/   intToStr(_acInput_AVG, &_dsp_data, 0);
                    LCD_Write_String(_dsp_data);
                    LCD_Write_String("V");
                    flush_dsp();
                    LCD_Set_Cursor(2,1);
                    LCD_Write_String("AC OUT:");
                    intToStr(_acOutput_AVG, &_dsp_data, 0);
                    LCD_Write_String(_dsp_data);
                    LCD_Write_String("V");
                    break;
                case 3:
                    LCD_Write_String("TEST FIELD 1");                  
                    flush_dsp();
                    LCD_Set_Cursor(2,1);
                    LCD_Write_String("TEMP:");
                    if(_result_temperature < 485) LCD_Write_String("OK");
                    else if(_result_temperature < 749) LCD_Write_String("COOLING");
                    else LCD_Write_String("HIGH");
                    break;
                case 4:
                    LCD_Write_String("TEST FIELD 2");
                    LCD_Set_Cursor(2,1);
                    if(_warning == _ALERT_OVERLOAD)         LCD_Write_String("OVERLOAD");
                    else if(_warning == _ALERT_LOW_BAT )    LCD_Write_String("LOW DC");
                    else if(_warning == _ALERT_TEMP)        LCD_Write_String("HIGH TEMP");
                    else if(_warning == _ALERT_MAINS_HIGH)  LCD_Write_String("AC HIGH");
                    else if(_warning == _ALERT_MAINS_LOW)   LCD_Write_String("AC LOW");
                    else if(_warning == _ALERT_MAINS_FAIL)  LCD_Write_String("INPUT FAIL");
                    _warning = 0;
                    break;
                default:
                    break;
            }
    }
    else{ 
        noBacklight();
    }
    return;
}

void _Traps(uint8_t _Trap_factor){
    uint16_t switch_scan_cnt;
    uint8_t _countdown_timer = 0;
    uint8_t _dynamic_error = 0;
    _disable_PWM();
    IEC0bits.INT0IE = 0;
    IEC0bits.ADIE = 0;
    IEC0bits.T1IE = 0;
    _CALIB_DIS();
    LCD_Clear();
    __delay_ms(10);
    LCD_Init();
    LCD_Set_Cursor(1,1);
    if(_Trap_factor == 1)       LCD_Write_String("SHORT");      //Static
    else if(_Trap_factor == 2)  LCD_Write_String("FBP");        //Static
    else if(_Trap_factor == 3)  LCD_Write_String("FBV");        //Static
    else if(_Trap_factor == 4)  LCD_Write_String("BAT FAIL");   //Static
    else if(_Trap_factor == 5)  LCD_Write_String("BAT LOW");    //Static
    else if(_Trap_factor == 6)  LCD_Write_String("SURGE");     //Dynamic
    else if(_Trap_factor == 7)  LCD_Write_String("OVERLOAD");   //Dynamic
    else if(_Trap_factor == 8)  LCD_Write_String("HIGH TEMP");  //Static
    else                        LCD_Write_String("ESD");        //static
    LCD_Write_String(" ERROR");
    
    if(_Trap_factor == 6 || _Trap_factor == 7)  _dynamic_error = 1;
    __delay_ms(10);
    _total_restart_time = Eeprom_ReadWord(_RESTART_ADDRESS);
    for(;;){
        _BUZZ_On();
        __delay_ms(500);
        _BUZZ_Off();
        for(switch_scan_cnt = 0; switch_scan_cnt < 500; switch_scan_cnt ++){
            __delay_ms(3);
            _Switch_Stat();
        }
        if(!_INV_Stat){
            _BUZZ_Off();
            __asm__ volatile ("reset");
        }
        
        if((_total_restart_time < 3) && (_dynamic_error)){
            _countdown_timer ++;
            if(_countdown_timer > 5){
                _total_restart_time ++;
                Eeprom_WriteWord(_RESTART_ADDRESS ,_total_restart_time);
                _BUZZ_Off();
                __asm__ volatile ("reset");
            }
        }
    }
    return;
}

void flush_dsp(void){
    unsigned char j;
    for(j = 0; j < 5; j++) _dsp_data[j] = '\0';
    return;
}

void _Switch_Stat(void){
    if(_SW_UPS_INV){
        if(_OnOff_Cnt < _DEBOUNCE_LIMIT) _OnOff_Cnt ++;
    }
    else{
        if(_OnOff_Cnt) _OnOff_Cnt --;
    }
        
    if(_OnOff_Cnt > _THRESHOLD_LIMIT){
        _INV_Stat = ON;
    }
    else{
        _INV_Stat = OFF;
    }
    
    return 0;
}

void _Calibrate_System(void){

}

uint8_t _Read_Switch(void){
    _Switch_Filter();
    for(;;){
        if(_LEFT) return 1;
        if(_RIGHT) return 3;
        if(_ENTER) return 2;
    }
    return 0;
}

void _Switch_Filter(void){
    while(_LEFT || _ENTER || _RIGHT) __delay_ms(1);
}

void intDisplay(uint16_t *_recieved_value){
    flush_dsp();
//    LCD_Init();
    for(;;){
        LCD_Set_Cursor(2,1);
        intToStr(*_recieved_value, &_dsp_data, 3);
        LCD_Write_String(_dsp_data);
        LCD_Write_String("    ");
        _return_value = _Read_Switch();
        if(_return_value == 1) *_recieved_value += 1;
        if(_return_value == 3 && *_recieved_value) *_recieved_value -= 1;
        if(_return_value == 2) {
            LCD_Set_Cursor(1,1);
            break;
        }
        __delay_ms(500);
    }
    __delay_ms(1000);
}